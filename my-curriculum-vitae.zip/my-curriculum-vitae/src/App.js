// Import React library
import React from 'react';
// Import CSS file
import './index.css';

// Define Header component
const Header = () => {
  return (
    <header className="header">
      <h1 className="name">Kagiso Tambekwayo</h1>
      <p className="title">Software Developer</p>
    </header>
  );
};

// Define AboutMe component
const AboutMe = () => {
  return (
    <section className="section">
      <h2 className="section-heading">About Me</h2>
      <p className="about-me-text">I am a passionate software developer with a focus on web development. I love creating innovative solutions to complex problems and enjoy working in collaborative environments.
      Results-driven IT Professional with expertise in consulting, web development, and database administration. Proven ability in system software, financial management, and project management. Seeking opportunities to leverage technical skills and contribute to dynamic teams.</p>
    </section>
  );
};

// Define Skills component
const Skills = () => {
  return (
    <section className="section">
      <h2 className="section-heading">Skills</h2>
      <ul className="skills-list">
        <li>JavaScript</li>
        <li>React</li>
        <li>Node.js</li>
        <li>HTML</li>
        <li>CSS</li>
        <li>Git</li>
      </ul>
    </section>
  );
};

// Define Education component
const Education = () => {
  return (
    <section className="section">
      <h2 className="section-heading">Education</h2>
      <div className="education-item">
        <h3 className="education-degree">Bachelor of Information Technology In Business Systems</h3>
        <p className="education-school">University of Pretoria</p>
        <p className="education-date">Graduated May 2018</p>
      </div>
    </section>
  );
};

// Define Experience component
const Experience = () => {
  return (
    <section className="section">
      <h2 className="section-heading">Experience</h2>
      <div className="experience-item">
        <h3 className="experience-title">Software Developer Intern</h3>
        <p className="experience-company">Zensar Technologies Pty(Ltd)</p>
        <p className="experience-date">June 2019 - August 2023</p>
        <ul className="experience-highlights">
          <li>Developed new features for company's web application using React.js</li>
          <li>Collaborated with team members to troubleshoot and debug issues</li>
          <li>Participated in code reviews and provided feedback on peers' code</li>
          <li>Keep track of agile developments and requirements using tools such as Jira and Confluence and SharePoint.</li>
          <li>Coding software programs to produce financial statements.</li>
        </ul>
      </div>
    </section>
  );
};

// Define Contact component
const Contact = () => {
  return (
    <section className="section">
      <h2 className="section-heading">Contact</h2>
      <ul className="contact-list">
        <li>Email: ktambekwayo@gmail.com</li>
        <li>Phone: (076) 608-9142</li>
        <li>LinkedIn: <a href="https://www.linkedin.com/in/kagiso-tambekwayo-b8537913a/">Kagiso</a></li>
        <li>Github: <a href="https://github.com/KagisoTee">KagisoTee</a></li>
      </ul>
    </section>
  );
};

// Define App component
const App = () => {
  return (
    <div className="cv">
      <Header />
      <AboutMe />
      <Skills />
      <Education />
      <Experience />
      <Contact />
    </div>
  );
};

// Export App component
export default App;
